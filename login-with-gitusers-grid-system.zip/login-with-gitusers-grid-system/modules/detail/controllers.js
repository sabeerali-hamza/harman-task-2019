      
'use strict';
 
angular.module('Detail')
 
.controller('DetailController',    ['$scope', '$http', '$rootScope',  function ($scope, $http, $rootScope) {
              // view single user below
             // alert('editUser');
             // $scope.editUser =  function(editUser) {
               // alert($scope.editUser);
                $http.get("https://api.github.com/users/"+$rootScope.editUser).then(function (response) {
                  $scope.singleUserData = response.data;
                    
              });
           // }
   }]);