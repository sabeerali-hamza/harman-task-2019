      
'use strict';
 
angular.module('Detail')
 
.controller('DetailController',    ['$scope', '$http',   function ($scope, $http) {
              // view single user below
             // alert('editUser');
             // $scope.editUser =  function(editUser) {
               // alert($scope.editUser);
                $http.get("https://api.github.com/users/"+$scope.editUser).then(function (response) {
                  $scope.singleUserData = response.data;
                    
              });
           // }
   }]);