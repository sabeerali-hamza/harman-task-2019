'use strict';
 
angular.module('Home', ['angularUtils.directives.dirPagination'])
 
.controller('HomeController',    ['$scope', '$http',   function ($scope, $http) {

    var scope = $scope;
   // $scope.IsVisible = true;
    $http.get("https://api.github.com/users?since=135").then(function (response) {
      $scope.users = response.data;
      var appendUsersData = [];
        angular.forEach($scope.users, function(value,key){
        appendUsersData.push( { login :  value.login, id : value.id, avatar_url : value.avatar_url, action : value.id } );
    });
    $scope.users=appendUsersData;
    $scope.people = $scope.users; 
  });
        scope.sortKey = 'login';
        scope.sortReverse = false;
        scope.itemsPerPage = 5;
        scope.sort = function(key){
            scope.sortReverse = (scope.sortKey == key) ? !scope.sortReverse : scope.sortReverse;
            scope.sortKey = key;
        }
            //   // view single user below
            //   $scope.editUser =  function(editUser) {
            //     alert(editUser);
            //     $http.get("https://api.github.com/users/"+editUser).then(function (response) {
            //       $scope.singleUserData = response.data;
            //   });
            // }
    }]);